#include<iostream>
using namespace std;
class rectangle
{
    int height ;
    int weight ;
public:
    int area();
    rectangle(int h, int w);
};

rectangle::rectangle(int h, int w)
{
    height = h;
    weight = w;
}
int rectangle::area()
{
    return height * weight ;
}
int main ()
{
    rectangle *p;
    rectangle object[5]= {rectangle(1,2),rectangle(2,3),rectangle(3,4),rectangle(4,5),rectangle(5,6)};
    rectangle rana (20,5);
    rectangle *lipi;
    lipi=&rana;
    p=object;
    int i;
         for( i=0; i<5; i++)
            cout<<i+1<<" = "<<(p+i)->area()<<endl;
            cout<<"Lipi + Rana "<<lipi->area()<<endl;
    return 0;
}
