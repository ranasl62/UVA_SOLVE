#include<iostream>
using namespace std;
class rectangle
{
    int height;
    int weight ;
public:
    void set(int h, int w)
    {
        height = h;
        weight = w;
    }
    int area()
    {
        return height*weight;
    }
};
rectangle scan()
{
    int h,w;
    cin>>h>>w;
    rectangle ob;
    ob.set(h,w);
    return ob;
}
void print(rectangle abc)
{
    cout<<abc.area()<<endl;
}
int main()
{
    rectangle obj;
    obj = scan();
    print(obj);

    return 0;
}
