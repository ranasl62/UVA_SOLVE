#include<cstdio>
int main ()
{
    char name[50];
    double salary,com;
    scanf("%s%lf%lf",name,&salary,&com);
    printf("TOTAL = R$ %lf",salary+com*15/100);
    return 0;
}
